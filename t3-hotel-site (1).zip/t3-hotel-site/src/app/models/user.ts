export interface User {
  _id: string;
  username: string;
  emailid: string;
  password: string;
  phoneno1: string;
  phoneno2: string;
  address: string;
  blacklist:string;
  comments: string;

  }