export class Item {
    
    _id!: string;
    itemname!: string;
    itemdesc!: string;
    price!: number;
    imagefilename!:any
      
}
