import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { ConfirmOrderComponent } from './components/confirm-order/confirm-order.component';
import { CartComponent } from './components/cart/cart.component';
import { MenuComponent } from './components/menu/menu.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { ItemAddComponent } from "./components/item-add/item-add.component";
import { ItemListComponent } from './components/item-list/item-list.component';
import { ItemEditComponent } from './components/item-edit/item-edit.component';
import { UserEditComponent } from './components/user-edit/user-edit.component';
import { AdminComponent } from './components/admin/admin.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { OrdersComponent } from './components/orders/orders.component';
import { OrderSuccessComponent } from './components/order-success/order-success.component';
import { UserEdit2Component } from './components/user-edit2/user-edit2.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { OrderPageComponent } from './components/order-page/order-page.component';
import { OrderListComponent } from './components/order-list/order-list.component';
import { OrderEditComponent } from './components/order-edit/order-edit.component';
const routes: Routes = [
  {path:"" , component:HomePageComponent},
  {path:"login", component:LoginComponent},
  {path:"register", component:RegisterComponent},
  {path:"confirm-Order", component:ConfirmOrderComponent},
  {path:"cart", component:CartComponent},
  {path:"menu", component:MenuComponent},
  {path:"user-profile", component:UserProfileComponent},
  {path:"item-add", component:ItemAddComponent},
  {path:"item-list", component:ItemListComponent},
  {path:"item-edit/:_id", component:ItemEditComponent},
  {path:"admin", component:AdminComponent},
  {path:"admin-dashboard", component:AdminDashboardComponent},
  {path:"user-list", component:UserListComponent},
  {path:"user-edit/:_id", component: UserEditComponent},
  {path:"orders", component:OrdersComponent},
  {path:"order-success", component:OrderSuccessComponent},
  {path:"user-edit2/:_id", component:UserEdit2Component},
  {path:"dashboard", component:DashboardComponent},
  {path:"user-dashboard", component:UserDashboardComponent},
  {path:"my-orders", component:OrderPageComponent },
  {path:"order-list", component:OrderListComponent},
  {path:"order-edit/:_id", component:OrderEditComponent},
  {path:"**", component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
