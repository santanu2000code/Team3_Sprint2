export class ItemClass {
  _id: string='';
  itemname: string='';
  itemdesc: string='';
  price: number=0;
  imagefilename:any;
  quantity:any;
  inputEl: any;
  subtotal:any;
}