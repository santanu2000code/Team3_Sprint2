export class UserClass {
  _id: string='';
  username: string='';
  emailid: string='';
  password: string='';
  phoneno1: string='';
  phoneno2: string='';
  confirmPassword: string='';
  address: string='';
}
