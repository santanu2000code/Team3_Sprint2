export class OrderClass {
  _id: string='';      
  itemname:string='';
  itemdesc: String='';
  price:number=0;
  quantity:number=0;
  imagefilename:String='';
}