import { Component, ElementRef, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ItemClass } from 'src/app/classes/item-class';
import { ItemService } from 'src/app/services/item.service';
import { OrderDeliveryService } from 'src/app/services/order-delivery.service';
import { CommonService } from "../../services/common.service";

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  items: ItemClass[] = [];
  total_no_of_records!: number;
  message = ''
  current_page: number = 1;
  quantity:number=0;
  no_of_cart_items=0;
  // itemname: any
  // itemdesc: any
  // price: any
  // imagefilename:any
  //  id: string='';
  constructor(private itemService:ItemService,
    private router:Router,private elementRef:ElementRef, private orderdeliveryService:OrderDeliveryService,
    public commonService:CommonService
    ) { }

  ngOnInit(): void {
    this.getItemList()
  }
  inc(item:any){
    // console.log(item)
    this.quantity+=1;
    item.quantity=this.quantity;
    // this.quantity=0;
  }
  dec(item:any){
    if(this.quantity!=1){
      this.quantity-=1;
    }
    item.quantity=this.quantity;
    // this.quantity=0;
  }
  getItemList() {
    this.itemService.getItems().subscribe(
      (result : any) => {
        this.items = result;
        this.total_no_of_records = this.items.length
      },
      (error) => {
       
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error
        }
      }
    );
  }
  

 
addToCart(item:ItemClass){
  if(this.quantity==0)
  {
    alert('select quantity of item')
  }
  let obj = {_id: item._id,itemname:item.itemname, price:item.price, quantity:item.quantity,
  itemdesc:item.itemdesc, imagefilename:item.imagefilename}
  console.log('obj')
  console.log(obj)
  this.commonService.addAnItemToCart(obj)
  this.no_of_cart_items++;
  
  this.quantity=0
  
}

MyCart(){
  this.router.navigateByUrl('/cart')
}

}