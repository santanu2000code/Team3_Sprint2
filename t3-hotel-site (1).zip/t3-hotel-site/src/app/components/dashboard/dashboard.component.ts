import { Component, OnInit } from '@angular/core';
import { ItemService } from 'src/app/services/item.service';
import { Item } from "./../../models/item";
import { CommonService } from 'src/app/services/common.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  username: any
  emailid: any
  _id:any
  items: Item[] = [];
  total_no_of_records!: number;
  message = ''
  current_page: number = 1;
  constructor(private itemService:ItemService, public commonService:CommonService) { }

  ngOnInit(): void {
    this.getItemList()
    this.username = this.commonService.getusername()
  this.emailid = this.commonService.getemailid()
  this._id = this.commonService.get_id()
  }

  getItemList() {
    this.itemService.getItems().subscribe(
      (result : any) => {
        this.items = result;
        this.total_no_of_records = this.items.length
      },
      (error) => {
        
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error
        }
      }
    );
  }
  
addCart(item:any){

}

}