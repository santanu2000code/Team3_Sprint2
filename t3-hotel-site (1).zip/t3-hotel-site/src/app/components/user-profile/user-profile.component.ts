import { Component, OnInit } from '@angular/core';
import { CommonService } from './../../services/common.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  username: string=''
  emailid: string=''
phoneno1:string=''
phoneno2:string=''
address:string=''
password:string=''
  constructor(public commonService:CommonService) { }
  private _router: any;
  user: any;
  
  logoutUser(){
    localStorage.removeItem('token')
    this._router.navigate(['/'])
  }
  ngOnInit(): void {
    this.username = this.commonService.getusername()
    this.emailid = this.commonService.getemailid()
    this.password = this.commonService.getpassword()
    this.phoneno1 = this.commonService.getphoneno1()
    this.phoneno2 = this.commonService.getphoneno2()
    this.address = this.commonService.getaddress()
  }

}