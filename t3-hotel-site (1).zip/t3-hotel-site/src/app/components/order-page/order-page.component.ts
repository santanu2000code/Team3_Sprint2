import { Component, OnInit } from '@angular/core';
import { OrderClass } from 'src/app/classes/order-class';
import { OrderDeliveryService } from 'src/app/services/order-delivery.service';

@Component({
  selector: 'app-order-page',
  templateUrl: './order-page.component.html',
  styleUrls: ['./order-page.component.css']
})
export class OrderPageComponent implements OnInit {

  constructor( private orderdeliveryService:OrderDeliveryService)  { }

  orders: OrderClass[] = [];
  total_no_of_records:any
  message = ''
  ngOnInit(): void {
    this.getAllOrders()
  }

  getAllOrders(){
    this.orderdeliveryService.getOrders().subscribe(
      (result : any) => {
        this.orders = result;
        this.total_no_of_records = this.orders.length
        // this.orders.forEach(subtotal = subtotal + this.amount)
        console.log(this.orders)
      },
      (error) => {
       
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error
        }
      }
    );
  }
}
