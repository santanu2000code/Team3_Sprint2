import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserEdit2Component } from './user-edit2.component';

describe('UserEdit2Component', () => {
  let component: UserEdit2Component;
  let fixture: ComponentFixture<UserEdit2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserEdit2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserEdit2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
