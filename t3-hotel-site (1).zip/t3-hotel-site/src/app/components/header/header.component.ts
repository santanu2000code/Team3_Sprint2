import { Route } from '@angular/compiler/src/core';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  // commonService: any;
  // router: any;
loggedin=''
email_id:any
  pass_word:any
  error:any
  constructor(private router:Router, public commonService:CommonService) { }

  ngOnInit(): void {
  }
  logout() {
    this.commonService.setLoginStatus(0)
    this.commonService.setJwtToken('');// Remove the Token from CommonService
    this.router.navigate(['/login']);// Redirect to Home Page
  }
 

}

