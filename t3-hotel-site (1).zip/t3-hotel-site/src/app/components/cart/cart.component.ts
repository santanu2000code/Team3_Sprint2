import { Component, OnInit } from '@angular/core';
import { OrderClass } from 'src/app/classes/order-class';
import { Item } from 'src/app/models/item';
import { OrderDeliveryService } from 'src/app/services/order-delivery.service';
import { OrdersComponent } from '../orders/orders.component';
import { CommonService } from "../../services/common.service";

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  
  orders: OrderClass[] = this.commonService.getCartItems()
  total_no_of_records:any
  message = ''
  // amount:any;
  subtotal:number = this.commonService.subtotal;
  grandtotal:number=0;
  deliverycharge:number=0;
  gstamount:number=0
  constructor(private orderdeliveryService:OrderDeliveryService, public commonService:CommonService) {
    }

  ngOnInit(): void {
    // let orders = this.commonService.getCartItems()
    this.commonService.AmountCalculation()
    this.subtotal= this.commonService.getSubTotal()
    this.grandtotal=this.commonService.getGrandTotal()
    this.deliverycharge=this.commonService.getDeliveryCharge()
    this.gstamount=this.commonService.getGSTamount()
  }

  delete1Order(order: OrderClass) {
    if(window.confirm(`Are you sure you want to delete ${order.itemname} item from the list?`)) {
      this.orderdeliveryService.deleteOrder(order._id)
        .subscribe( (data: any) => {
          this.orders = this.orders.filter(u => u !== order);
        })
    }
  }
  
}