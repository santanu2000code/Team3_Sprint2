import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from "src/app/services/common.service";
import { OrderDeliveryService } from 'src/app/services/order-delivery.service';

@Component({
  selector: 'app-confirm-order',
  templateUrl: './confirm-order.component.html',
  styleUrls: ['./confirm-order.component.css']
})
export class ConfirmOrderComponent implements OnInit {
  username: any
  emailid: any
  _id:any
  address: any
  phoneno1:any
  phoneno2:any
  minDate = new Date();
  maxDate = new Date(2021,8,24)
  deliveryaddress:any;
  
 // address1: any

  constructor( public router:Router, public commonService:CommonService,private orderdeliveryService:OrderDeliveryService) {

   }

  ngOnInit(): void {
  this.username = this.commonService.getusername()
  this.emailid = this.commonService.getemailid()
  this._id = this.commonService.get_id()
  this.address = this.commonService.getaddress()
  this.phoneno1 = this.commonService.getphoneno1()
  this.phoneno2 = this.commonService.getphoneno2()
  
  }
 
placeOrder()
{
  // Read Cart Items & User details from Common service
  this.commonService.getCartItems()
  let order = this.commonService.getItemDetails()
  this.orderdeliveryService.createOrder(order).subscribe((res: any)=>{
    // alert('Your Order got placed Successfully')
    console.log(res);
  })
  this.router.navigateByUrl('/order-success')
}
}