import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { CommonService } from 'src/app/services/common.service';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  emailid:any
  password:any
  error:any
  error_message: string='';
  constructor(private router:Router, private userService: UserService, private commonService: CommonService) { }

  ngOnInit(): void {
  }
  adminlogin(){
    if(this.emailid=="admin@hotelsaravana.com" ){
      var body = "&emailid=" + this.emailid 
          + "&password=" + this.password;
      
      this.userService.checkValidUser(body)
        .subscribe( data => {
          console.log('Login Result / JWT Token :')
          console.log(data)
          alert('Login successful')
          if(data !== 'Login Failed') {// Login Successful, Got JWT Token
            //localStorage.setItem('loggedin', 'yes');
            // this.commonService.setJwtToken(data);// Store the Token in to CommonService
            // this.commonService.setLoginStatus(1);
  
  
            const result = JSON.parse(data)
            this.commonService.setLoginStatus(1);
            this.commonService.set_id(result['_id']);
            this.commonService.setusername(result['username']);
            this.commonService.setemailid(result['emailid']);
            this.commonService.setpassword(result['password']);
            
            this.commonService.setJwtToken(result['jwtToken']);
  
            localStorage.setItem('jwtToken', result['jwtToken']);  
            localStorage.setItem('username', result['username']); 
            localStorage.setItem('emailid', result['emailid']); 
      this.router.navigate(['admin-dashboard']);
    } else {
      this.error_message = data// To Show Error Message in Login Page
    }
  });
        }
      }
    }