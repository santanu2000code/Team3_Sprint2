import { Component, OnInit } from '@angular/core';

import { CommonService } from 'src/app/services/common.service';
@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  username: any
  emailid: any
  _id:any
  address: any
  phoneno1:any

  constructor( public commonService:CommonService) { }

  ngOnInit(): void {
    this.username = this.commonService.getusername()
  this.emailid = this.commonService.getemailid()
  this._id = this.commonService.get_id()
  this.address = this.commonService.getaddress()
  this.phoneno1 = this.commonService.getphoneno1()
  }

}
