import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonService } from './common.service';
import { Order } from '../models/order';


@Injectable({
  providedIn: 'root'
})
export class OrderDeliveryService {
  
  api_url:string = "http://localhost:9000/v1/order/"
  jwtToken: any;
  headers:any
 
  constructor(private http:HttpClient, private commonService:CommonService) { }

 
    getItem() {
      return this.http.get(this.api_url);
    }
    getOrders() {
      //return this.http.get(this.api_url);
      this.jwtToken = this.commonService.getJwtToken()
      this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
      //console.log('ItemService getItems() : ' + this.jwtToken)
      return this.http.get(this.api_url, {headers: this.headers});
    }
    createOrder(formData: any) {
      //let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
      this.jwtToken = this.commonService.getJwtToken()
      this.headers  = new HttpHeaders({"Authorization": this.jwtToken});
      return this.http.post(this.api_url, formData, {headers:this.headers, responseType:'text'});
      // return this.http.post(this.api_url, formData);
    }
    deleteOrder(itemid: string) {
      //return this.http.get(this.api_url + '/delete/' + itemid);//Interim
      // return this.http.delete(this.api_url + '/' + itemid);//Actual
      this.jwtToken = this.commonService.getJwtToken()
      this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
      return this.http.delete(this.api_url + itemid, {headers: this.headers});//Actual
    }
    // emptyCart(){
    //    this.jwtToken = this.commonService.getJwtToken()
    //   this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
    //    return this.http.delete(this.api_url, {headers: this.headers});
    // }
    // removeCart(): void {
    //   this.http.emptyCart().subscribe(() => {
    //     this.getOrders();
    //     alert('Cart Emptied');
    //   });
    // }
    getOrderById(orderid: string){
      this.jwtToken = this.commonService.getJwtToken()
      this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
      return this.http.get<Order>(this.api_url + orderid, {headers: this.headers});
    }
    updateOrder(body: string, orderid: string){
      this.jwtToken = this.commonService.getJwtToken()
      this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
      return this.http.put(this.api_url + orderid, body, {headers: this.headers, responseType:'text'});
    }
}
