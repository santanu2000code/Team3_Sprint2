import { Injectable } from '@angular/core';
import { OrderClass } from "../classes/order-class";
import { OrderDeliveryService } from './order-delivery.service';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
 
  public loginStatus = 0;// 0 = not logged in, 1 = logged in
  public jwtToken = '';// JWT - Json Web Token
  public _id = '';
  public username = '';
  public emailid = '';
  public password = '';
  public phoneno1 = '';
  public phoneno2= '';
  public address = '';
  public gstpercentage:number=0.10;
  cartItems:OrderClass[] = [] //itemname, price & quantity
 
  public subtotal:number=0;
  public grandtotal:number=0;
  public deliverycharge:number=0;
  public gstamount:number=0
  constructor() { }

  resetAll() {
    this.loginStatus = 0;
    this.jwtToken = '';
    this._id = '';
    this.username = '';
    this.emailid = '';
    this.password = '';
    this.phoneno1= '';
    this.phoneno2= '';
    this.address = '';
    this.gstpercentage=0.10;   
  }

  addAnItemToCart(cartItem:OrderClass) {
    this.cartItems.push(cartItem)
    alert('Added 1 item in to Cart')
    console.log("this.cartItems")
    console.log(this.cartItems)
    //alert(this.cartItems)
  }

  AmountCalculation(){
    this.cartItems = this.getCartItems()
    
    this.cartItems.forEach(order => {
      this.subtotal += order.price * order.quantity
    });

    if(this.subtotal <= 500 ){
      this.deliverycharge = 50;
    }
    else {
      this.deliverycharge = 0;
    }
    this.grandtotal += this.deliverycharge

    this.gstamount = this.gstpercentage * this.subtotal
    this.grandtotal = this.gstamount + this.deliverycharge + this.subtotal
    
  }
  // GSTpercentage(){ return this.gstpercentage; }
  getSubTotal(){return this.subtotal }
  getGSTamount(){ return this.gstamount }
  getDeliveryCharge(){ return this.deliverycharge }
  getGrandTotal(){ return this.grandtotal}
  getCartItems() { return this.cartItems; }

  getItemDetails(){
    
    let order = {
      username:this.username,
      emailid:this.emailid,
      permanentaddress:this.address,
      deliveryaddress:'deliveryaddress',
      phoneno1:this.phoneno1,
      phoneno2:this.phoneno2,
      ordereddate:new Date(),
      deliverydate:new Date(),
      subtotal:this.subtotal,
      gstpercentage:this.gstpercentage,
      gstamount:this.gstamount,
      deliverycharge:this.deliverycharge,
      grandtotal:this.grandtotal,
      status:'Ordered',
      itemname1:this.cartItems[0].itemname,
      itemdesc1:this.cartItems[0].itemdesc,
      price1:this.cartItems[0].price,
      quantity1:this.cartItems[0].quantity,
      imagefilename1:this.cartItems[0].imagefilename,
      itemname2:this.cartItems[1].itemname,
      itemdesc2:this.cartItems[1].itemdesc,
      price2:this.cartItems[1].price,
      quantity2:this.cartItems[1].quantity,
      imagefilename2:this.cartItems[1].imagefilename,
      orderedtime:'',
      deliverytime:''
        }
  // console.log('Amar Place Order')
  // console.log('cartItems')
  console.log(this.cartItems)
  // console.log('order')
  // console.log(order)
    return order
  }

  clearCart() { this.cartItems = [] }

  setLoginStatus(status : number) { this.loginStatus = status; }
  getLoginStatus() { return this.loginStatus }
  
  setJwtToken(token : string) { this.jwtToken = token; }
  getJwtToken() { return this.jwtToken; }

  set_id(x : string) { this._id = x; }
  get_id() { return this._id; }
 
  setusername(x : string) { this.username = x; }
  getusername() { return this.username; }
  
  setemailid(x : string) { this.emailid = x;}
  getemailid() { return this.emailid; }
  
  setpassword(x : string) { this.password = x; }
  getpassword() { return this.password; }

  setphoneno1(x : string) { this.phoneno1 = x; }
  getphoneno1() { return this.phoneno1; }

  setphoneno2(x : string) { this.phoneno2 = x; }
  getphoneno2() { return this.phoneno2; }

  setaddress(x : string) { this.address= x;}
  getaddress() { return this.address; }
 
}